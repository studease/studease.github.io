nohup ./check.sh >/dev/null 2>&1 &
