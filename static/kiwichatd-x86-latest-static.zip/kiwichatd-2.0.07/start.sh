nohup ./bin/kiwichatd >/dev/null 2>&1 &
