1. /etc/hosts
127.0.0.1 vrf.studease.cn

2. 
#service network restart

3. run
#./start.sh

4. start rtmpmate

