nohup ./bin/rmkgd -m "000c2959373d" >/dev/null 2>&1 &
