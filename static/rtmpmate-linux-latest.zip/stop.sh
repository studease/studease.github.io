#!/bin/bash

pids=$(ps x | grep mated | grep -v grep | awk '{print $1}')
for pid in $pids; do
	echo "killing rtmpmate process ${pid}..."
	kill -9 $pid
done

