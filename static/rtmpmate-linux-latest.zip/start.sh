nohup ./bin/mated >/dev/null 2>&1 &
